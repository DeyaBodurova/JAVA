package person;

public interface Birthable {
    String getBirthDate();
}
