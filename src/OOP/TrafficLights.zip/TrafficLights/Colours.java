package OOP.TrafficLights;

public enum Colours {
    RED,
    GREEN,
    YELLOW;
}
