package OOP;

public enum Suits {
    CLUBS ,
    DIAMONDS ,
    HEARTS ,
    SPADES ;

//    private int value;
//
//    Suits (int value) {
//        this.value = value;
//    }

//    public int getValue() {
//        return value;
//    }
}
