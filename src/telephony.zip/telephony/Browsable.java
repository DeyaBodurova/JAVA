package telephony;

public interface Browsable {
    String browsable();
}
